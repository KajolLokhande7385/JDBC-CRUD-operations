package jdbcproject1.fetch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentFetch {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/weje2?user=root&password=root");
		Statement statement=connection.createStatement();
		ResultSet resultset=statement.executeQuery("select * from emp");
		
		while (resultset.next()) {
			System.out.println(resultset.getInt(1));
			System.out.println(resultset.getString(2));
			System.out.println(resultset.getString(3));
			System.out.println(resultset.getInt(4));
			System.out.println(resultset.getLong(5));
			System.out.println(resultset.getString(6));
			System.out.println(resultset.getString(7));
			System.out.println("----------------------------------");
		}
		connection.close();
		
	}

}
