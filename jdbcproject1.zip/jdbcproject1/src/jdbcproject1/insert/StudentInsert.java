package jdbcproject1.insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentInsert {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/weje2?user=root&password=root");
		Statement statement=connection.createStatement();
		statement.execute("insert into emp values(11,'jiya','B+ve','26',1134567892,'jiya@gmail.com','mumbai'),(7,'yash','AB+ve','16',1134567892,'yash@gmail.com','mumbai')");
		connection.close();
		
	}

}
